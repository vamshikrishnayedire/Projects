DROP DATABASE IF EXISTS PROJECT1;

CREATE DATABASE PROJECT1;

USE PROJECT1;


CREATE TABLE PROJECT1.USER (
	  email_ID varchar(155) NOT NULL,
	  username varchar(155) NOT NULL,
	  password varchar(40) NOT NULL,
      displayname varchar(50) NOT NULL,
	  PRIMARY KEY (email_ID),
	  UNIQUE KEY (username),
      UNIQUE KEY (displayname)
	  );
	  
      CREATE TABLE PROJECT1.DEPARTMENT (
	  department_ID int(11) NOT NULL,	  
	  PRIMARY KEY (department_ID)	  
	);
    
	  CREATE TABLE PROJECT1.STUDENT (
	  stu_email_ID varchar(155) NOT NULL,
	  PRIMARY KEY (stu_email_id),
	  FOREIGN KEY (stu_email_ID) REFERENCES USER (email_ID)
	);

	CREATE TABLE PROJECT1.STAFF (
	  sta_email_ID varchar(155) NOT NULL,
      department_ID int(11) NOT NULL,
	  PRIMARY KEY (sta_email_ID, department_id),
	  FOREIGN KEY (sta_email_ID) REFERENCES USER (email_ID),
      FOREIGN KEY (department_ID) REFERENCES DEPARTMENT (department_ID)
	);
    
    CREATE TABLE PROJECT1.PROFESSOR (
	  pro_email_ID varchar(155) NOT NULL,
      department_ID int(11) NOT NULL,
	  PRIMARY KEY (pro_email_ID, department_id),
	  FOREIGN KEY (pro_email_ID) REFERENCES USER (email_ID),
      FOREIGN KEY (department_ID) REFERENCES DEPARTMENT (department_ID)
	);
    
    CREATE TABLE PROJECT1.COURSE (
	  course_No int(32) NOT NULL,
	  course_name varchar(50) NOT NULL,
      capacity int(4) NOT NULL,
      course_dept int(11) NOT NULL,      
	  PRIMARY KEY (course_No),
      FOREIGN KEY (course_dept) REFERENCES DEPARTMENT (department_ID)
	  );
      
      CREATE TABLE PROJECT1.SEMESTER (
	  semester_name varchar(50) NOT NULL,
	  PRIMARY KEY (semester_name)
	  );
    
    CREATE TABLE PROJECT1.SEM_HAS_COURSE (
	  semester_name varchar(50) NOT NULL,
      course_No int(10) NOT NULL,
      stu_email_id varchar(155) NOT NULL,
      ta_email_id varchar(155) NOT NULL,
      ins_email_id varchar(155) NOT NULL,
      primary key(semester_name, course_no, stu_email_id, ta_email_id, ins_email_id ),
	  FOREIGN KEY (semester_name) REFERENCES SEMESTER (semester_name),
      FOREIGN KEY (course_No) REFERENCES COURSE (course_No),
      FOREIGN KEY (stu_email_id) REFERENCES STUDENT (stu_email_id),
      FOREIGN KEY (ta_email_id) REFERENCES TA (ta_email_id),
      FOREIGN KEY (ins_email_id) REFERENCES INSTRUCTOR (ins_email_id)
	  );
    
    CREATE TABLE PROJECT1.TA (
	  ta_email_ID varchar(155) NOT NULL,
      semester_name varchar(50) NOT NULL,
      course_No int(10) NOT NULL,
	  PRIMARY KEY (ta_email_ID, semester_name, course_No),
	  FOREIGN KEY (ta_email_ID) REFERENCES STUDENT (stu_email_ID),
      FOREIGN KEY (semester_name) REFERENCES SEM_HAS_COURSE (semester_name),
      FOREIGN KEY (course_No) REFERENCES SEM_HAS_COURSE (course_No)
	);
    
    CREATE TABLE PROJECT1.INSTRUCTOR (
	  ins_email_ID varchar(155) NOT NULL,
      semester_name varchar(50) NOT NULL,
      course_No int(10) NOT NULL,
	  PRIMARY KEY (ins_email_ID, semester_name, course_No),
	  FOREIGN KEY (ins_email_ID) REFERENCES PROFESSOR (pro_email_ID),
      FOREIGN KEY (semester_name) REFERENCES SEM_HAS_COURSE (semester_name),
      FOREIGN KEY (course_No) REFERENCES SEM_HAS_COURSE (course_No)
	);
      
      
      CREATE TABLE PROJECT1.CAN_MAJORS_IN (
	  stu_email_ID varchar(155) NOT NULL,
      department_ID int(11) NOT NULL,
      primary key (student_id, department_id),
	  FOREIGN KEY (stu_email_ID) REFERENCES STUDENT (stu_email_ID),
      FOREIGN KEY (department_ID) REFERENCES DEPARTMENT (department_ID)
	  );
      
      
      
      CREATE TABLE PROJECT1.CAN_ENROLL (
	  stu_email_ID varchar(155) NOT NULL,
      course_No int(10) NOT NULL,
      semester_name varchar(50) NOT NULL,
      course_grade char(1) NOT NULL,
      primary key (stu_email_id, course_No, semester_name),
	  FOREIGN KEY (stu_email_ID) REFERENCES STUDENT (stu_email_ID),
      FOREIGN KEY (course_No) REFERENCES SEM_HAS_COURSE (course_No),
      FOREIGN KEY (semester_name) REFERENCES SEM_HAS_COURSE (semester_name)
	  );
      
      CREATE TABLE PROJECT1.FEEDBACK_TO_INS (
	  stu_email_ID varchar(155) NOT NULL,      
      ins_email_id varchar(155) NOT NULL,
      course_No int(10) NOT NULL,
      semester_name varchar(50) NOT NULL,
      feedback_ins varchar(150) NOT NULL,
      primary key (stu_email_id, course_No, semester_name, ins_email_id),
	  FOREIGN KEY (stu_email_ID) REFERENCES ENROLL (stu_email_ID),      
      FOREIGN KEY (ins_email_ID) REFERENCES SEM_HAS_COURSE (ins_email_ID),
      FOREIGN KEY (course_No) REFERENCES SEM_HAS_COURSE (course_No),
      FOREIGN KEY (semester_name) REFERENCES SEM_HAS_COURSE (semester_name)
	  );
      
      CREATE TABLE PROJECT1.FEEDBACK_TO_TA (
	  stu_email_ID varchar(155) NOT NULL,      
      ta_email_id varchar(155) NOT NULL,
      course_No int(10) NOT NULL,
      semester_name varchar(50) NOT NULL,
      feedback_ins varchar(150) NOT NULL,
      primary key (stu_email_id, course_No, semester_name, ta_email_id),
	  FOREIGN KEY (stu_email_ID) REFERENCES ENROLL (stu_email_ID),
      FOREIGN KEY (ta_email_ID) REFERENCES SEM_HAS_COURSE (ta_email_ID),      
      FOREIGN KEY (course_No) REFERENCES SEM_HAS_COURSE (course_No),
      FOREIGN KEY (semester_name) REFERENCES SEM_HAS_COURSE (semester_name)
	  );
      
      CREATE TABLE PROJECT1.EXAM (
	  semester_name varchar(50) NOT NULL,
      course_No int(10) NOT NULL,
      exam_id int(10) NOT NULL,
      primary key(semester_name, course_no, exam_id),
	  FOREIGN KEY (semester_name) REFERENCES SEMESTER_HAS_COURSE (semester_name),
      FOREIGN KEY (course_No) REFERENCES SEMESTER_HAS_COURSE (course_No)
	  );
      
      CREATE TABLE PROJECT1.PROBLEMS (
	  exam_id int(10) NOT NULL,
      prob_no int(10) NOT NULL,
      primary key(exam_id, prob_no),
      FOREIGN KEY (exam_id) REFERENCES EXAM (exam_id)
	  );
      
      
      CREATE TABLE PROJECT1.ATTENDS (
	  semester_name varchar(50) NOT NULL,
      course_No int(10) NOT NULL,
      stu_email_id varchar(155) NOT NULL,   
      exam_id int(10) NOT NULL,
      exam_grade char(1) NOT NULL,
      primary key(semester_name, course_no,stu_email_id),
	  FOREIGN KEY (semester_name) REFERENCES EXAM (semester_name),
      FOREIGN KEY (course_No) REFERENCES EXAM (course_No),
      FOREIGN KEY (stu_email_ID) REFERENCES ENROLL (stu_email_ID),
      FOREIGN KEY (exam_ID) REFERENCES EXAM (exam_ID)
	  );
      
      
